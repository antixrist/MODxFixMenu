<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for MODxFixMenu.

0.0.1-beta
==============
- Init',
    'license' => 'Creative Commons Attribution-ShareAlike 4.0 International Public License

http://creativecommons.org/licenses/by-sa/4.0/legalcode
',
    'readme' => '--------------------
MODxFixMenu
--------------------
Author: Kartashov Alexey <ya.antixrist@gmail.com>
--------------------

Enhancement top menu for MODx Revolution:
 - change open submenu by hover/click
 - adjustable transition
 - adjustable closed timeout

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/antixrist/MODxFixMenu/issues',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '83911b24fcd6355452eb4e992d856d93',
      'native_key' => 'modxfixmenu',
      'filename' => 'modNamespace/6b9e58ce62d328159feaa99cbf93a784.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a94e1f0afcb1d72353d12dc323a21abe',
      'native_key' => 'modxfixmenu.open_by_click',
      'filename' => 'modSystemSetting/264c11b3a4d7bb4126f9b02ec237378a.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f22c33bc308c97d6f2f9d73d5a0fe1c8',
      'native_key' => 'modxfixmenu.transition',
      'filename' => 'modSystemSetting/9285825c25adb996efc6bed39fcb06c7.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c7083802f38612cbbe911ccaf03ae09',
      'native_key' => 'modxfixmenu.autoclose_timeout',
      'filename' => 'modSystemSetting/d84dd2d2c6e5bae27c6550ced0e1b57e.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d91402494acfc5d4711d5a26beaf164',
      'native_key' => 'modxfixmenu.css_classname',
      'filename' => 'modSystemSetting/322a58f34354801c09272cd9e617f08e.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a40005104e5a11de5ba48932e04aff31',
      'native_key' => 'modxfixmenu.assets_path',
      'filename' => 'modSystemSetting/664e7002421fcd03beb89a18332cceb2.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b2b92b5c9085970e9c740f9c61d1a76',
      'native_key' => 'modxfixmenu.assets_url',
      'filename' => 'modSystemSetting/b939b52ae7ed40c98ad27db7ea5082ab.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcaedc40069f6a1a68b0e5594eaf81cb',
      'native_key' => 'modxfixmenu.core_path',
      'filename' => 'modSystemSetting/ac9d84d0ee3147590e373b13bbc7085d.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd748820dce04115e0479f403e9bef828',
      'native_key' => NULL,
      'filename' => 'modCategory/19507174a06005f8a1baf770f5ded514.vehicle',
      'namespace' => 'modxfixmenu',
    ),
  ),
);