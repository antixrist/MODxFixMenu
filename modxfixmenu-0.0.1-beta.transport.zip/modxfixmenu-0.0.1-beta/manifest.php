<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for MODxFixMenu.

0.0.1-beta
==============
- Init',
    'license' => 'Creative Commons Attribution-ShareAlike 4.0 International Public License

http://creativecommons.org/licenses/by-sa/4.0/legalcode
',
    'readme' => '--------------------
MODxFixMenu
--------------------
Author: Kartashov Alexey <ya.antixrist@gmail.com>
--------------------

Enhancement top menu for MODx Revolution:
 - change open submenu by hover/click
 - adjustable transition
 - adjustable closed timeout

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/antixrist/MODxFixMenu/issues',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f7a28123929819b6492f225693d0eda7',
      'native_key' => 'modxfixmenu',
      'filename' => 'modNamespace/3f66937258d5df65aad4e1f7c4aacd7d.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bb75b04a3b4650cb1d4f20ec12ccea0',
      'native_key' => 'modxfixmenu.open_by_click',
      'filename' => 'modSystemSetting/b3a8b7e63fc43ba71ecd43ba405cdab2.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd458b0f723b678fb198be66f1482b593',
      'native_key' => 'modxfixmenu.transition',
      'filename' => 'modSystemSetting/213b40898a6c125a1beb72daa1dff847.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecb0a4466d872983758159febf5ee3a8',
      'native_key' => 'modxfixmenu.autoclose_timeout',
      'filename' => 'modSystemSetting/54dc1ca7ae61095036242a670584ec72.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '683900397c713c1495186f88a9e6d8b7',
      'native_key' => 'modxfixmenu.css_classname',
      'filename' => 'modSystemSetting/bf69a130bbd1e6ea5ee62d13f5f149b8.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34a66327deaa96b169db0a5f895bd93d',
      'native_key' => 'modxfixmenu.assets_path',
      'filename' => 'modSystemSetting/f183a1909f93a7dcb60e9486393b2bd1.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1814f25f3270ea834d61c0401c86e4e3',
      'native_key' => 'modxfixmenu.assets_url',
      'filename' => 'modSystemSetting/c2ee7e238899627ce7ef256b821801f3.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3ee743277f8082e56aac31b149b98ec',
      'native_key' => 'modxfixmenu.core_path',
      'filename' => 'modSystemSetting/5068075bcab721cc2cc707ab9cdc1826.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b71bc8a27e4f52ad6997ea93f0fb3c4b',
      'native_key' => NULL,
      'filename' => 'modCategory/607bdb9ad36dc2a622f5cabf75b05913.vehicle',
      'namespace' => 'modxfixmenu',
    ),
  ),
);