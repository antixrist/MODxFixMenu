--------------------
MODxFixMenu
--------------------
Author: Kartashov Alexey <ya.antixrist@gmail.com>
--------------------

Enhancement top menu for MODx Revolution:
 - change open submenu by hover/click
 - adjustable transition
 - adjustable closed timeout

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/antixrist/MODxFixMenu/issues