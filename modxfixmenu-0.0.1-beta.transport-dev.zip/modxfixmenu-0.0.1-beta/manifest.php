<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for MODxFixMenu.

0.0.1-beta
==============
- Init',
    'license' => 'Creative Commons Attribution-ShareAlike 4.0 International Public License

http://creativecommons.org/licenses/by-sa/4.0/legalcode
',
    'readme' => '--------------------
MODxFixMenu
--------------------
Author: Kartashov Alexey <ya.antixrist@gmail.com>
--------------------

Enhancement top menu for MODx Revolution:
 - change open submenu by hover/click
 - adjustable transition
 - adjustable closed timeout

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/antixrist/MODxFixMenu/issues',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5e311f7c1cd60d8ba224e0eec450d85c',
      'native_key' => 'modxfixmenu',
      'filename' => 'modNamespace/949c90da288f7e2483173a8b0c173d4d.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5745631349c0a334ec719f6ec13eb49a',
      'native_key' => 'modxfixmenu.open_by_click',
      'filename' => 'modSystemSetting/6ce504b4c1637bcc31e57771a0f70271.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04bd11e8c5979f231c8118231600d2fb',
      'native_key' => 'modxfixmenu.transition',
      'filename' => 'modSystemSetting/a40a0cf97249b7844fa6b5d4fcdab47b.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a814506af3f5a7c793d8d3a5f19f98ed',
      'native_key' => 'modxfixmenu.autoclose_timeout',
      'filename' => 'modSystemSetting/b194205f77e424d3f2ed11da8c183bec.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89749fe9ce0732d2c759db99a4dcbad0',
      'native_key' => 'modxfixmenu.css_classname',
      'filename' => 'modSystemSetting/f350a74fccde44b9dbc94c1439bdd03a.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5c610641850e81d9bd46b1ac40edf35',
      'native_key' => 'modxfixmenu.assets_path',
      'filename' => 'modSystemSetting/35f2062241df54c0b171c6442ec8bf66.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7f485543d5bcbc904427914db690a86',
      'native_key' => 'modxfixmenu.assets_url',
      'filename' => 'modSystemSetting/6fb14ad797bbcaeb653cc190dcbc855c.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f919a948f7c6024ee2ea7d6ef19d1f9e',
      'native_key' => 'modxfixmenu.core_path',
      'filename' => 'modSystemSetting/c1ba527807896d5c05d34f0f4f66abf1.vehicle',
      'namespace' => 'modxfixmenu',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b43d6efc78c0757b7e3b738e20270fb9',
      'native_key' => NULL,
      'filename' => 'modCategory/52073dac7812f2ce1cd8d1f27863bc24.vehicle',
      'namespace' => 'modxfixmenu',
    ),
  ),
);